#include <stdio.h>
#include <stdlib.h>
#include "vm.h"
#include "API.h"
#include "list.h"

int fifoQueue[256];
int fifoIndex = 0;
int currentPage;
int lreArray[256];
int lruTimestamp[256];
int currentTime = 0;
int oldestFrame = 0;
int clockHand = 0;
bool useBit[256];
bool isHot[256];
bool isResident[256];
int coldHand = 0;
int hotHand = 0;

void initialize_global_data(int numFrames) {
	int i;
    for (i = 0; i < numFrames; i++) {
        lruTimestamp[i] = __INT_MAX__;   
        fifoQueue[i] = -1;              
        useBit[i] = false;              
    }
    fifoIndex = 0;
	currentPage = -1;
    clockHand = 0;
    currentTime = 0;
	coldHand = 0;
	hotHand = 0;
}

int fifo(int numFrames)
{
	// if (fifoQueue[fifoIndex] == -1) {
	// 	fprintf(stderr, "Error: FIFO conatins invalid entries. \n");
	// 	exit(EXIT_FAILURE);
	// }

	int victimFrame = fifoQueue[fifoIndex];

	if (victimFrame == -1) {
		fprintf(stderr, "Error: FIFO conatins invalid entries. \n");
		exit(EXIT_FAILURE);
	}
	// fifoQueue[fifoIndex] = currentPage;	
	fifoIndex = (fifoIndex + 1) % numFrames;
	return victimFrame;
	
}

int lru(int numFrames)
{
	int oldestTime = __INT_MAX__;
	int victimFrame = -1;
	int i;
	for( i = 0; i < numFrames; i++){
		if(lruTimestamp[i] < oldestTime) {
			oldestTime = lruTimestamp[i];
			victimFrame = i;
		}
	}
		if(victimFrame == -1) {
			fprintf(stderr, "Error: No suitable frame found for lRU");
			exit(EXIT_FAILURE);
		}
		return victimFrame;
}

int clock(int numFrames) {
    int startClockHand = clockHand;
    int i;
    int victimFrame;

    // First pass: Look for a frame with useBit = false
    for (i = 0; i < numFrames; i++) {
        if (!useBit[clockHand]) {
            victimFrame = clockHand;
            clockHand = (clockHand + 1) % numFrames;
            return victimFrame;
        } else {
            clockHand = (clockHand + 1) % numFrames;
        }
    }

    // Second pass: Reset useBit for all frames and look again
    for (i = 0; i < numFrames; i++) {
        useBit[i] = false;  // Reset all useBits
    }

    // Third pass: Look again for a frame with useBit = false
    for (i = 0; i < numFrames; i++) {
        if (!useBit[clockHand]) {
            victimFrame = clockHand;
            clockHand = (clockHand + 1) % numFrames;
            return victimFrame;
        }
        clockHand = (clockHand + 1) % numFrames;
    }

    // If we somehow still don't find a frame, throw an error (this shouldn't happen)
    fprintf(stderr, "Error: No available frame found in clock replacement.\n");
    exit(EXIT_FAILURE);
}


void initialize_clock_pro(int numFrames) {
	int i;
	for (i = 0; i < numFrames; i++) {
        useBit[i] = false;
        isHot[i] = false;
        isResident[i] = true;
    }
    coldHand = 0;
    hotHand = 0;
}

int clock_pro(int numFrames)
{	
	while (true) {
        // First, try to find a Cold page to evict
        while (!isHot[coldHand]) {  // Only check Cold pages
            if (!useBit[coldHand]) {  // Not recently used, can be evicted
                int victimFrame = coldHand;
                isResident[victimFrame] = false;
                isHot[victimFrame] = false; // Mark as Cold
                coldHand = (coldHand + 1) % numFrames;
                return victimFrame;  // Evict this Cold page
            } else {
                // Recently used, reset the use bit
                useBit[coldHand] = false;
            }
            coldHand = (coldHand + 1) % numFrames;
        }
		while (isHot[hotHand]) {  // Only check Hot pages
            if (!useBit[hotHand]) {
                isHot[hotHand] = false;  // Demote to Cold
                hotHand = (hotHand + 1) % numFrames;
            } else {
                useBit[hotHand] = false;  // Reset recently used status
            }
            hotHand = (hotHand + 1) % numFrames;
        }
    }

}

void update_replacement_policy(int frame, bool isPageFault) {
	currentTime++;

	if(replacementPolicy == FIFO && isPageFault) {
		// if(fifoIndex < 256) {
			fifoQueue[fifoIndex] = frame;
		// }
		fifoIndex = (fifoIndex + 1) % MAX_PFN;
		
	}
	else if (replacementPolicy == LRU) {
		lruTimestamp[frame] = currentTime;
	}
	// if(isPageFault)
	// {
	// 	printf("FIFO Queue: ");

	// 	fifoQueue[fifoIndex] = frame;
	// 	fifoIndex = (fifoIndex + 1 ) % MAX_PFN;
	// 	printf("fifoIndex: %d\n", fifoIndex);
	// 	useBit[frame] = true;
	// }
	// if(fifoIndex < 256) {
	// 	fifoQueue[fifoIndex] = frame;
	// }
	// fifoIndex = (fifoIndex + 1) % 256;
	// useBit[frame] = true;
}


/*========================================================================*/

int find_replacement()
{
		int PFN;
		if(replacementPolicy == ZERO)  PFN = 0;
		else if(replacementPolicy == FIFO)  PFN = fifo(MAX_PFN);
		else if(replacementPolicy == LRU)
			PFN = lru(MAX_PFN);
		else if(replacementPolicy == CLOCK) PFN = clock(MAX_PFN);
		else if(replacementPolicy == CLOCK_PRO) PFN = clock_pro(MAX_PFN);

		return PFN;
}

int pagefault_handler(int pid, int VPN, char reqType)
{
		int PFN;
		// find a free PFN.
		PFN = get_freeframe();
		currentPage = VPN;
		
		// no free frame available. find a victim using a page replacement algorithm. ;
		if(PFN < 0) {
				PFN = find_replacement();
				/* ---- */
				IPTE victimPage = read_IPTE(PFN);
				PTE victimPTE = read_PTE(victimPage.pid, victimPage.VPN);

				if (victimPTE.dirty) {
					swap_out(victimPage.pid, victimPage.VPN, PFN);
				}
				victimPTE.valid = false;
				write_PTE(victimPage.pid, victimPage.VPN, victimPTE);
		}

		swap_in(pid, VPN, PFN);

		PTE newPTE = { .PFN = PFN, .valid = true, .dirty = (reqType == 'W')};
		write_PTE(pid, VPN, newPTE);

		IPTE newIPTE = { .pid = pid, .VPN = VPN};
		write_IPTE(PFN, newIPTE);
		
		/* ---- */
		update_replacement_policy(PFN, true);

		return PFN;
}

int get_PFN(int pid, int VPN, char reqType)
{
		/* Read page table entry for (pid, VPN) */
		PTE pte = read_PTE(pid, VPN);

		/* if PTE is valid, it is a page hit. Return physical frame number (PFN) */
		if(pte.valid) {
		/* Mark the page dirty, if it is a write request */
				if(reqType == 'W') {
						pte.dirty = true;
						write_PTE(pid, VPN, pte);
				}
				return pte.PFN;
		}
		
		/* PageFault, if the PTE is invalid. Return -1 */
		return -1;
}

int MMU(int pid, int virtAddr, char reqType, bool *hit)
{
		int PFN, physicalAddr;

		int VPN = (virtAddr >> 8) & 0xFF;
		currentPage = VPN;
		int offset = virtAddr & 0xFF;
		
		/* calculate VPN and offset
		VPN = ...
		offset = ...
		*/
		
		// read page table to get Physical Frame Number (PFN)
		PFN = get_PFN(pid, VPN, reqType);
		if(PFN >= 0) { // page hit
				stats.hitCount++;
				*hit = true;
		} else { // page miss
				stats.missCount++;
				*hit = false;
				PFN = pagefault_handler(pid, VPN, reqType);
		}

		physicalAddr = (PFN << 8) + offset;
		return physicalAddr;
}

