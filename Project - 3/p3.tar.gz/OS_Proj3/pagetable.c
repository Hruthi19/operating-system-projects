#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "vm.h"
#include "API.h"
#include "list.h"

#define MAX_PAGES 256
#define MAX_FRAMES 256

int handPosition = 0;           
int pageReferenced[MAX_FRAMES]; 
int pageSecondChance[MAX_FRAMES]; 
int memoryFrames[MAX_FRAMES];     

struct Node *fifoQueueHead = NULL;  
struct Node *lruPageList = NULL;    
int lruPageTracker[MAX_PAGES];        

void initialize_fifo() {
    fifoQueueHead = NULL;
}

void initialize_lru() {
    int i;
    lruPageList = NULL;
    for (i = 0; i < MAX_PAGES; i++) {
        lruPageTracker[i] = 0; 
        
    }
}

int fifo() {
    if (fifoQueueHead == NULL) {
        fprintf(stderr, "FIFO queue is empty! No frames to replace.\n");
        exit(EXIT_FAILURE);
    }

    int victimFrame = fifoQueueHead->data;
    fifoQueueHead = list_remove_head(fifoQueueHead); 
    return victimFrame;
}

void add_to_fifo(int frameNumber) {
    fifoQueueHead = list_insert_tail(fifoQueueHead, frameNumber); 
}

int lru() {
    if (lruPageList == NULL) {
        fprintf(stderr, "LRU list is empty! No frames to replace.\n");
        exit(EXIT_FAILURE);
    }
    int victimFrame = lruPageList->data;
    lruPageList = list_remove_head(lruPageList); 
    lruPageTracker[victimFrame] = 0; 
    return victimFrame;
}

void update_lru(int frameNumber) {
    lruPageList = list_remove(lruPageList, frameNumber);
    lruPageList = list_insert_tail(lruPageList, frameNumber);

    lruPageTracker[frameNumber] = 1; 
}

void initialize_clock() {
    int i;
    handPosition = 0;
    for (i = 0; i < MAX_FRAMES; i++) {
        pageReferenced[i] = 0; 
        pageSecondChance[i] = 0; 
        memoryFrames[i] = -1;     
    }
}

int clock() {
    while (1) {
        if (pageReferenced[handPosition] == 0) {
            int victimPFN = memoryFrames[handPosition];
            memoryFrames[handPosition] = -1;           
            pageReferenced[handPosition] = 0;        
            handPosition = (handPosition + 1) % MAX_FRAMES; 
            return victimPFN;
        }
        pageReferenced[handPosition] = 0;
        handPosition = (handPosition + 1) % MAX_FRAMES;  
    }
}

int clock_pro() {
    while (1) {
        if (pageReferenced[handPosition] == 0 && pageSecondChance[handPosition] == 0) {
            int victimPFN = memoryFrames[handPosition];
            memoryFrames[handPosition] = -1; 
            pageReferenced[handPosition] = 0; 
            pageSecondChance[handPosition] = 0; 
            handPosition = (handPosition + 1) % MAX_FRAMES; 
            return victimPFN;
        }
        
        if (pageReferenced[handPosition] == 1 && pageSecondChance[handPosition] == 0) {
            pageSecondChance[handPosition] = 1; 
        }
        else if (pageSecondChance[handPosition] == 1) {
            pageReferenced[handPosition] = 0; 
            pageSecondChance[handPosition] = 0; 
        }
        
        handPosition = (handPosition + 1) % MAX_FRAMES; 
    }
}

int pagefault_handler(int pid, int VPN, char reqType) {
    int PFN;
    PFN = get_freeframe();

    if (PFN < 0) {
        PFN = find_replacement();
        IPTE victim = read_IPTE(PFN);
        PTE victimPTE = read_PTE(victim.pid, victim.VPN);
        if (victimPTE.dirty) {
            swap_out(victim.pid, victim.VPN, PFN);
        }
        victimPTE.valid = false;
        write_PTE(victim.pid, victim.VPN, victimPTE);
    }
    swap_in(pid, VPN, PFN);

    PTE newPTE = { .PFN = PFN, .valid = true, .dirty = (reqType == 'W') };
    write_PTE(pid, VPN, newPTE);

    IPTE newIPTE = { .pid = pid, .VPN = VPN };
    write_IPTE(PFN, newIPTE);

    if (replacementPolicy == FIFO) add_to_fifo(PFN);
    else if (replacementPolicy == LRU) update_lru(PFN);
    else if (replacementPolicy == CLOCK) {
        memoryFrames[PFN] = VPN; 
        pageReferenced[PFN] = 1; 
    }
    else if (replacementPolicy == CLOCK_PRO) {
        memoryFrames[PFN] = VPN; 
        pageReferenced[PFN] = 1; 
        pageSecondChance[PFN] = 0; 
    }

    return PFN;
}

int get_PFN(int pid, int VPN, char reqType) {
    PTE pte = read_PTE(pid, VPN);

    if (pte.valid) {
        if (reqType == 'W') {
            pte.dirty = true;
            write_PTE(pid, VPN, pte);
        }

        if (replacementPolicy == LRU) update_lru(pte.PFN);
        else if (replacementPolicy == CLOCK) pageReferenced[pte.PFN] = 1; 

        return pte.PFN;
    }
    return -1;
}

int MMU(int pid, int virtAddr, char reqType, bool *hit) {
    int PFN, physicalAddr;
    int VPN = (virtAddr >> 8) & 0xFF; 
    int offset = virtAddr & 0xFF;     

    PFN = get_PFN(pid, VPN, reqType);
    if (PFN >= 0) {
        stats.hitCount++;
        *hit = true;
    } else {
        stats.missCount++;
        *hit = false;
        PFN = pagefault_handler(pid, VPN, reqType);
    }

    physicalAddr = (PFN << 8) + offset;
    return physicalAddr;
}

int find_replacement() {
    int PFN;
    if (replacementPolicy == FIFO) PFN = fifo(); 
    else if (replacementPolicy == LRU) PFN = lru();   
    else if (replacementPolicy == CLOCK) PFN = clock(); 
    else if (replacementPolicy == CLOCK_PRO) PFN = clock_pro(); 

    return PFN;
}